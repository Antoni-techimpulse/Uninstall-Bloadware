---
name: Bug report
about: Reportar un problema de ejecución
---

## Descripción

## Versión/build de Windows

## Pasos de reproducción

## Resultado esperado

## Resultado obtenido

## Extracto de log

```text
Pega aquí el fragmento relevante, eliminando datos personales.
```
