---
name: Feature request
about: Solicitar mejora o nueva opción
---

## Objetivo

## Caso de uso

## Riesgos o impacto funcional

## Propuesta técnica
